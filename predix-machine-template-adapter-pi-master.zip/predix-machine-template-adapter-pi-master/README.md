<a href="http://predixdev.github.io/predix-machine-template-adapter-pi/javadocs/index.html" target="_blank" >
	<img height="50px" width="100px" src="images/javadoc.png" alt="view javadoc"></a>
&nbsp;
<a href="http://predixdev.github.io/predix-machine-template-adapter-pi" target="_blank">
	<img height="50px" width="100px" src="images/pages.jpg" alt="view github pages">
</a>
# predix-workshop-machine
Machine bundle for Predix workshop

[![Analytics](https://ga-beacon.appspot.com/UA-82773213-1/predix-machine-template-adapter-pi/readme?pixel)](https://github.com/PredixDev)
